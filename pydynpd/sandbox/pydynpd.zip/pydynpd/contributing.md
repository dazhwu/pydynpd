# Contributing

There are several ways to contribute to pydynpd!
- Submit issue/bug reports [here](https://github.com/wouterboomsma/eigency/issues),
or try to fix the problem yourself and then [submit a pull request](https://github.com/wouterboomsma/eigency/pulls).
- Request features or ask questions [here](https://github.com/wouterboomsma/eigency/issues).
- Browse [the source code](https://github.com/wouterboomsma/eigency) and see if anything looks out of place - let us know!

