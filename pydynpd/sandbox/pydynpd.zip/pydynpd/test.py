import pandas as pd
from  pydynpd import regression

df = pd.read_csv("test.csv")  #, index_col=False)
